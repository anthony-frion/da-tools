from typing import List

from da_tools.system.state import State

ListOfStates = List[State]
