
.. include:: ../../README.rst


--------------------------------------------

API Reference
-------------

.. toctree::
    :maxdepth: 2
    :hidden:

    self

.. autosummary::
    :toctree: _autosummary
    :recursive:
    :template: custom-module.rst

    da_tools
